#!/bin/sh

echo "sh "$0" {exec|exec gui|exit|con|act|deact|dis|del}"

exec_with_echo()
{
    echo $1
    $1
}

case "$1" in 
    "exec")
	if [ $2 = "gui" ]; then
	    gnome-terminal -t JuliusRTC -e 'juliusrtc --gui'
	    gnome-terminal -t SEAT -e 'seat --gui'
	    COM1="gnome-terminal"
	    COM1="$COM1 --tab -t PulseAudioInput -e pulseaudioinput"
	    COM1="$COM1 --tab -t PulseAudioOutput -e pulseaudiooutput"
	    COM1="$COM1 --tab -t OpenJTalkRTC -e openjtalkrtc"
	    exec_with_echo "$COM1 &"
	else
	    gnome-terminal -t JuliusRTC -e 'juliusrtc test.grxml'
	    gnome-terminal -t SEAT -e 'seat test.seatml'
	    COM1="gnome-terminal"
	    COM1="$COM1 --tab -t PulseAudioInput -e pulseaudioinput"
	    COM1="$COM1 --tab -t PulseAudioOutput -e pulseaudiooutput"
	    COM1="$COM1 --tab -t OpenJTalkRTC -e openjtalkrtc"
	    exec_with_echo "$COM1 &"
	fi
	;;
    "exit")
	killall pulseaudioinput
	killall pulseaudiooutput
	killall openjtalkrtc
	killall juliusrtc
	killall seat
	;;
esac

case "$1" in
    "con")
        . shell/setenv.sh
        exec_with_echo "sh shell/connect_HRI.sh con"
        echo ""
        ;;
    "act")
        . shell/setenv.sh
        exec_with_echo "sh shell/activate_HRI.sh act"
        echo ""
        ;;
    "deact")
        . shell/setenv.sh
        exec_with_echo "sh shell/activate_HRI.sh deact"
        echo ""
        ;;
    "dis")
        . shell/setenv.sh
        exec_with_echo "sh shell/connect_HRI.sh dis"
        echo ""
        ;;
    "del")
        . shell/setenv.sh
        exec_with_echo "sh shell/delete_HRI.sh"
        echo ""
        ;;
esac