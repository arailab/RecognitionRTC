#!/bin/sh

echo "sh "$0" {exec|exec gui|exit|con temp|con obse|act|deact|dis|del|make|remake|clean}"

exec_with_echo()
{
    echo $1
    $1
}

exec_with_echo_bg()
{
    echo $1
    $1 &
}

exec_onlyone_process()
{
    if [ `ps -ef | grep $1 |grep -v grep | wc -l` -ne 1 ]; then
        echo "$1 &"
        $1 &
    fi
}

check_process()
{
    if [ `ps -ef | grep $1 |grep -v grep | wc -l` -ne 1 ]; then
        return 0
    fi
    return 1
}

case "$1" in 
    "exec")
	COM="gnome-terminal"
	if [ $2 = "gui" ]; then
	    sh voice_script.sh exec gui
	else
	    sh voice_script.sh exec 
	fi
        ;;
    "exit")
	sh voice_script.sh exit
esac


while read PROG_PATH PROG_NAME RTC_CONF
do
    if [ -z "$PROG_PATH" ]; then
        continue
    fi
    if [ $PROG_PATH = "#" ]; then
        continue
    fi

    case "$1" in
        "exec")
            # 二重起動防止
            check_process ./${PROG_NAME}Comp
            if [ $? = 1 ]; then
                echo ${PROG_NAME} is running
                continue
            else
                echo "$PROG_PATH $PROG_NAME"
            fi

            #COM="$COM --tab --working-directory=`pwd`/$PROG_PATH -t $PROG_NAME -e \"./${PROG_NAME}Comp -f ${RTC_CONF}\""
            COM="$COM --tab --working-directory=`pwd`/modules/$PROG_PATH -t $PROG_NAME -e ./${PROG_NAME}Comp"
            # exec_with_echo "cd ${PROG_PATH}"
            # exec_with_echo_bg "./${PROG_NAME}Comp -f ${RTC_CONF}"
            # exec_with_echo "cd .."
            echo ""
            ;;
        "exit")
            exec_with_echo "killall -9 ${PROG_NAME}Comp"
            echo ""
            ;;
        "make")
            DIR="`pwd`"
            exec_with_echo "cd modules/${PROG_PATH}"
            exec_with_echo "make -f Makefile.${PROG_NAME}"
            exec_with_echo "cd $DIR"
            echo ""
            ;;
        "remake")
            DIR="`pwd`"
            exec_with_echo "cd modules/${PROG_PATH}"
            exec_with_echo "make -f Makefile.${PROG_NAME} clean"
            exec_with_echo "make -f Makefile.${PROG_NAME}"
            exec_with_echo "cd $DIR"
            echo ""
            ;;
        "clean")
            DIR="`pwd`"
            exec_with_echo "cd modules/${PROG_PATH}"
            exec_with_echo "make -f Makefile.${PROG_NAME} clean"
            exec_with_echo "cd $DIR"
            echo ""
            ;;
    esac
done < "rtclist.conf"

case "$1" in
    "exec")
        exec_with_echo "$COM &"
esac


case "$1" in
    "con")
        . shell/setenv.sh
        case "$2" in
            "temp")
             exec_with_echo "sh shell/all_connect_without_danger.sh con temp"
             ;;
            "obse")
             exec_with_echo "sh shell/all_connect_without_danger.sh con obse"
             ;;
        esac
        echo ""
        ;;
    "act")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_activate_without_danger.sh act"
        echo ""
        ;;
    "deact")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_activate.sh deact"
        echo ""
        ;;
    "dis")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_connect_without_danger.sh dis"
        echo ""
        ;;
    "del")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_delete.sh"
        echo ""
        ;;
esac