#!/bin/sh
#********************************************************
# script to delete zombie components
#********************************************************

rtdel -z $NSPC/PulseAudioInput0.rtc
rtdel -z $NSPC/PulseAudioOutput0.rtc
rtdel -z $NSPC/JuliusRTC0.rtc
rtdel -z $NSPC/OpenJTalkRTC0.rtc
rtdel -z $NSPC/SEAT0.rtc
rtdel -z $NS2809/TemplateMatching0.rtc
rtdel -z $NS2809/OSAKA/ObjectSensor0.rtc
rtdel -z $NS2809/RecognitionManager0.rtc
rtdel -z $NS2809/Viewer0.rtc
rtdel -z $NS2809/CaptureCamera0.rtc