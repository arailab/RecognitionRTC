#!/bin/sh
#
#********************************************************
# component connect script
#********************************************************

# set environment variable
#. setenv.sh

COM="rtcon"
case "$1" in
    "con")
        COM="rtcon"
        ;;
    "dis")
        COM="rtdis"
        ;;
esac

echo "==============================================================================="
echo "Component Connections of Voice Recognition"
echo "==============================================================================="
$COM $NSPC/PulseAudioInput0.rtc:AudioDataOut \
     $NSPC/JuliusRTC0.rtc:data 
$COM $NSPC/SEAT0.rtc:speechin \
     $NSPC/JuliusRTC0.rtc:result 
$COM $NSPC/SEAT0.rtc:speechout \
     $NSPC/OpenJTalkRTC0.rtc:text 
$COM $NSPC/PulseAudioOutput0.rtc:AudioDataIn \
     $NSPC/OpenJTalkRTC0.rtc:result 
     
echo "*******************************************************************************"
echo "Component Connection OK!!"
echo "*******************************************************************************"
