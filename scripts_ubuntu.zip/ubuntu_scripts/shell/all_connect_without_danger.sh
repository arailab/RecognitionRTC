#!/bin/sh
#
#********************************************************
# component connect script
#********************************************************

# set environment variable
#. setenv.sh

COM="rtcon"
case "$1" in
    "con")
        COM="rtcon"
        ;;
    "dis")
        COM="rtdis"
        ;;
esac

echo "==============================================================================="
echo "Component Connections of All Components"
echo "==============================================================================="

$COM $NSPC/PulseAudioInput0.rtc:AudioDataOut \
     $NSPC/JuliusRTC0.rtc:data 
$COM $NSPC/SEAT0.rtc:speechin \
     $NSPC/JuliusRTC0.rtc:result 
$COM $NSPC/SEAT0.rtc:speechout \
     $NSPC/OpenJTalkRTC0.rtc:text 
$COM $NSPC/PulseAudioOutput0.rtc:AudioDataIn \
     $NSPC/OpenJTalkRTC0.rtc:result 

$COM $NS2809/RecognitionManager0.rtc:word \
     $NSPC/OpenJTalkRTC0.rtc:text 
$COM $NS2809/RecognitionManager0.rtc:voice \
     $NSPC/SEAT0.rtc:commandout 

if [ $2 = "temp" ]; then
    $COM $NS2809/TemplateMatching0.rtc:InImage \
         $NS2809/CaptureCamera0.rtc:CameraImage 
    $COM $NS2809/TemplateMatching0.rtc:OutImage \
         $NS2809/Viewer0.rtc:Image 
    $COM $NS2809/RecognitionManager0.rtc:Model \
         $NS2809/TemplateMatching0.rtc:Model 
    
elif [ $2 = "obse" ]; then
    $COM $NS2809/OSAKA/ObjectSensor0.rtc:.SingleImage \
         $NS2809/CaptureCamera0.rtc:CameraImage 
    $COM $NS2809/OSAKA/ObjectSensor0.rtc:.ResultImg \
         $NS2809/Viewer0.rtc:Image 
    $COM $NS2809/RecognitionManager0.rtc:Model \
         $NS2809/OSAKA/ObjectSensor0.rtc:.Model   
else
    $COM $NS2809/TemplateMatching0.rtc:InImage \
         $NS2809/CaptureCamera0.rtc:CameraImage 
    $COM $NS2809/TemplateMatching0.rtc:OutImage \
         $NS2809/Viewer0.rtc:Image 
    $COM $NS2809/RecognitionManager0.rtc:Model \
         $NS2809/TemplateMatching0.rtc:Model     
    $COM $NS2809/OSAKA/ObjectSensor0.rtc:.SingleImage \
         $NS2809/CaptureCamera0.rtc:CameraImage 
    $COM $NS2809/OSAKA/ObjectSensor0.rtc:.ResultImg \
         $NS2809/Viewer0.rtc:Image 
    $COM $NS2809/RecognitionManager0.rtc:Model \
         $NS2809/OSAKA/ObjectSensor0.rtc:.Model
fi
echo "*******************************************************************************"
echo "ALL Component Connection OK!!"
echo "*******************************************************************************"
