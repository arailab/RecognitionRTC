#!/bin/sh
#********************************************************
#  all component activate script
#********************************************************
COM="rtact"
case "$1" in
    "act")
        COM="rtact"
        ;;
    "deact")
        COM="rtdeact"
        ;;
esac

$COM $NSPC/PulseAudioInput0.rtc
$COM $NSPC/PulseAudioOutput0.rtc
$COM $NSPC/JuliusRTC0.rtc
$COM $NSPC/OpenJTalkRTC0.rtc
$COM $NSPC/SEAT0.rtc
$COM $NS2809/TemplateMatching0.rtc
$COM $NS2809/OSAKA/ObjectSensor0.rtc
$COM $NS2809/RecognitionManager0.rtc
$COM $NS2809/Viewer0.rtc
$COM $NS2809/CaptureCamera0.rtc


echo "********************************************************"
echo "Finish to activate all components"
echo "********************************************************"
