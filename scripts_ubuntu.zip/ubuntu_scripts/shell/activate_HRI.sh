#!/bin/sh
#********************************************************
#  OpenHRI components activate script
#********************************************************
COM="rtact"
case "$1" in
    "act")
        COM="rtact"
        ;;
    "deact")
        COM="rtdeact"
        ;;
esac

$COM $NSPC/PulseAudioInput0.rtc
$COM $NSPC/PulseAudioOutput0.rtc
$COM $NSPC/JuliusRTC0.rtc
$COM $NSPC/OpenJTalkRTC0.rtc
$COM $NSPC/SEAT0.rtc

echo "********************************************************"
echo "Finish to activate OpenHRI componets"
echo "********************************************************"
