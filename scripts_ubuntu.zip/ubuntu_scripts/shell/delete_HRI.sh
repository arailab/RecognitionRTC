#!/bin/sh
#********************************************************
#component delete script
#********************************************************

# set environment variable
#source setenv.sh

rtdel $NS2809/PulseAudioInput0.rtc
rtdel $NS2809/PulseAudioOutput0.rtc
rtdel $NS2809/JuliusRTC0.rtc
rtdel $NS2809/OpenJTalkRTC0.rtc
rtdel $NS2809/SEAT0.rtc
