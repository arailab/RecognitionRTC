// -*- C++ -*-
/*!
 * @file  RecognitionManager.cpp
 * @brief mangement of recognitoin of voice and object
 * @date $Date$
 *
 * $Id$
 */

#include "RecognitionManager.h"

// Module specification
// <rtc-template block="module_spec">
static const char* recognitionmanager_spec[] =
  {
    "implementation_id", "RecognitionManager",
    "type_name",         "RecognitionManager",
    "description",       "mangement of recognitoin of voice and object",
    "version",           "1.0.0",
    "vendor",            "Kyohei Iwane Osaka Univ.",
    "category",          "Manager",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
RecognitionManager::RecognitionManager(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_voiceIn("voice", m_voice),
    m_wordOut("word", m_word),
    m_ModelPort("Model")

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
RecognitionManager::~RecognitionManager()
{
}



RTC::ReturnCode_t RecognitionManager::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("voice", m_voiceIn);
  
  // Set OutPort buffer
  addOutPort("word", m_wordOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  m_ModelPort.registerConsumer("ModelAcceptor", "AcceptModelService", m_ModelAcceptor);
  
  // Set CORBA Service Ports
  addPort(m_ModelPort);
  
  // </rtc-template>

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t RecognitionManager::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t RecognitionManager::onActivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}


RTC::ReturnCode_t RecognitionManager::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}


RTC::ReturnCode_t RecognitionManager::onExecute(RTC::UniqueId ec_id)
{
 if(m_voiceIn.isNew() ){
    m_voiceIn.read();
    std::cout << "m_voice.data = " << m_voice.data << std::endl;  
    std::string data;
    data = m_voice.data;
    //m_ModelAcceptor->setModel(data.c_str() );
    //    m_VoiceRecognitionService.setResult( data );
    AcceptModelService::OctetSeq model;	model.length(data.length());
    memcpy(&model[0], data.c_str(), sizeof(char)*data.length());    
    std::cout << "start set model  " << std::endl;	
    m_ModelAcceptor->setModel(model);
  }
	
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t RecognitionManager::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t RecognitionManager::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void RecognitionManagerInit(RTC::Manager* manager)
  {
    coil::Properties profile(recognitionmanager_spec);
    manager->registerFactory(profile,
                             RTC::Create<RecognitionManager>,
                             RTC::Delete<RecognitionManager>);
  }
  
};


